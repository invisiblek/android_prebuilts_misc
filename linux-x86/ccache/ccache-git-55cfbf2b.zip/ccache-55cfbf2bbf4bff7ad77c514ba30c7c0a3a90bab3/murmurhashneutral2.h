#ifndef MURMURHASHNEUTRAL2_H
#define MURMURHASHNEUTRAL2_H

unsigned int murmurhashneutral2(const void *key, int len, unsigned int seed);

#endif
